package com.example.screenocr

object Config {
    /** Языки Tesseract через "+", например "rus+eng" или "rus+eng+ukr". Файлы скачаются автоматически. */
    const val LANGS = "rus+eng"

    /** Как часто проверять область, мс. */
    const val INTERVAL_MS = 700L

    /** Во сколько раз увеличивать картинку перед OCR. */
    const val UPSCALE = 2

    /** Текст короче этого игнорируется (отсекает мусор). */
    const val MIN_CHARS = 3

    /** Два чтения подряд считаются одним текстом, если похожи не меньше чем на это. */
    const val SAME_RATIO = 0.9

    /** Текст считается новым, если похож на прошлый скопированный меньше чем на это. */
    const val NEW_RATIO = 0.8
}
