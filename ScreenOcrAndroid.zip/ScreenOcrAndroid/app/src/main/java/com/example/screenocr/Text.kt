package com.example.screenocr

object Text {
    fun normalize(s: String): String =
        s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.joinToString(" ")

    /** Похожесть строк от 0 до 1 (по расстоянию Левенштейна). */
    fun similarity(a: String, b: String): Double {
        val x = a.lowercase()
        val y = b.lowercase()
        if (x.isEmpty() && y.isEmpty()) return 1.0
        val m = x.length
        val n = y.length
        var prev = IntArray(n + 1) { it }
        var cur = IntArray(n + 1)
        for (i in 1..m) {
            cur[0] = i
            for (j in 1..n) {
                val cost = if (x[i - 1] == y[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            val t = prev
            prev = cur
            cur = t
        }
        return 1.0 - prev[n].toDouble() / maxOf(m, n)
    }
}
