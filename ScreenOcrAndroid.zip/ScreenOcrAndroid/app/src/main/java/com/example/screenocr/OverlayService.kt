package com.example.screenocr

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import cz.adaptech.tesseract4android.TessBaseAPI

class OverlayService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        @Volatile
        var running = false
        val history = StringBuilder()
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var capW = 0
    private var capH = 0

    private lateinit var frameView: FrameView
    private lateinit var frameParams: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var btnMode: Button

    private var worker: Thread? = null

    @Volatile private var alive = false
    @Volatile private var watching = false
    @Volatile private var captureRect: Rect? = null
    @Volatile private var dropFrame = false
    @Volatile private var lastRead = ""
    @Volatile private var lastCopied = ""
    private var lastFrame: Bitmap? = null

    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || running) return START_NOT_STICKY

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notification)
        }

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, main)

        running = true
        startCapture()
        createOverlays()
        alive = true
        worker = Thread { workerLoop() }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("ocr", "Screen OCR", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, "ocr")
            .setContentTitle("Screen OCR работает")
            .setContentText("Чтобы выйти, нажми ✕ в плавающей панели")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setOngoing(true)
            .build()
    }

    // ---------------- Захват экрана ----------------

    private fun screenSize(): Triple<Int, Int, Int> {
        val dm = DisplayMetrics()
        val display = (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)
        @Suppress("DEPRECATION")
        display.getRealMetrics(dm)
        return Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    private fun startCapture() {
        val (w, h, dpi) = screenSize()
        capW = w
        capH = h
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        imageReader = reader
        virtualDisplay = projection?.createVirtualDisplay(
            "ocr-capture", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, null
        )
    }

    /** Если экран повернули, подстраиваем размер захвата. */
    private fun ensureCapture() {
        val (w, h, dpi) = screenSize()
        if (w == capW && h == capH) return
        val old = imageReader
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        virtualDisplay?.resize(w, h, dpi)
        virtualDisplay?.surface = reader.surface
        imageReader = reader
        old?.close()
        capW = w
        capH = h
        lastFrame?.recycle()
        lastFrame = null
    }

    /** Новый кадр, если он есть; иначе последний известный (экран мог не меняться). */
    private fun grabFrame(): Bitmap? {
        val img = imageReader?.acquireLatestImage()
        if (img != null) {
            try {
                val p = img.planes[0]
                val rowPadding = p.rowStride - p.pixelStride * img.width
                val wide = Bitmap.createBitmap(
                    img.width + rowPadding / p.pixelStride, img.height, Bitmap.Config.ARGB_8888
                )
                wide.copyPixelsFromBuffer(p.buffer)
                val fresh = if (rowPadding == 0) wide else {
                    Bitmap.createBitmap(wide, 0, 0, img.width, img.height).also { wide.recycle() }
                }
                val old = lastFrame
                lastFrame = fresh
                old?.recycle()
            } finally {
                img.close()
            }
        }
        return lastFrame
    }

    // ---------------- Рамка и панель ----------------

    private fun createOverlays() {
        val (sw, sh, _) = screenSize()
        frameView = FrameView(this, 3.dp())

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        frameParams = WindowManager.LayoutParams(
            (sw * 0.7).toInt(), 120.dp(), type, flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (sw * 0.15).toInt()
            y = (sh * 0.7).toInt()
        }

        frameView.onDrag = { dx, dy ->
            frameParams.x += dx
            frameParams.y += dy
            wm.updateViewLayout(frameView, frameParams)
        }
        frameView.onResize = { dw, dh ->
            frameParams.width = maxOf(80.dp(), frameParams.width + dw)
            frameParams.height = maxOf(40.dp(), frameParams.height + dh)
            wm.updateViewLayout(frameView, frameParams)
        }
        wm.addView(frameView, frameParams)

        createPanel(type)
    }

    private fun createPanel(type: Int) {
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xCC222222.toInt())
            setPadding(8.dp(), 4.dp(), 8.dp(), 4.dp())
        }
        val grip = TextView(this).apply {
            text = "⠿"
            setTextColor(Color.WHITE)
            textSize = 24f
            setPadding(8.dp(), 0, 16.dp(), 0)
        }
        btnMode = Button(this).apply {
            text = "▶ Слежка"
            setOnClickListener { toggleWatch() }
        }
        val btnExit = Button(this).apply {
            text = "✕"
            setOnClickListener { stopSelf() }
        }
        panel.addView(grip)
        panel.addView(btnMode)
        panel.addView(btnExit)

        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16.dp()
            y = 120.dp()
        }

        var lx = 0f
        var ly = 0f
        grip.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    lx = e.rawX
                    ly = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    panelParams.x += (e.rawX - lx).toInt()
                    panelParams.y += (e.rawY - ly).toInt()
                    lx = e.rawX
                    ly = e.rawY
                    wm.updateViewLayout(panel, panelParams)
                }
            }
            true
        }
        wm.addView(panel, panelParams)
    }

    private fun toggleWatch() {
        if (!watching) {
            // запоминаем область ВНУТРИ рамки (в пикселях экрана)
            val loc = IntArray(2)
            frameView.getLocationOnScreen(loc)
            val b = frameView.borderPx + 2
            captureRect = Rect(
                loc[0] + b, loc[1] + b,
                loc[0] + frameView.width - b, loc[1] + frameView.height - b
            )
            lastRead = ""
            lastCopied = ""
            dropFrame = true
            // в режиме слежки рамка пропускает касания, видео можно нормально смотреть
            frameParams.flags = frameParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            frameView.editMode = false
            watching = true
            btnMode.text = "⏸ Рамка"
        } else {
            watching = false
            frameParams.flags =
                frameParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            frameView.editMode = true
            btnMode.text = "▶ Слежка"
        }
        wm.updateViewLayout(frameView, frameParams)
    }

    // ---------------- OCR ----------------

    private fun workerLoop() {
        val tess = TessBaseAPI()
        if (!tess.init(filesDir.absolutePath, Config.LANGS)) {
            toast("Не удалось загрузить языки OCR. Открой приложение и нажми «Старт» заново.")
            main.post { stopSelf() }
            return
        }
        tess.setPageSegMode(6) // один блок текста

        while (alive) {
            val t0 = SystemClock.elapsedRealtime()
            try {
                if (watching) processOnce(tess) else imageReader?.acquireLatestImage()?.close()
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                toast("Ошибка: ${e.message}")
            }
            val rest = Config.INTERVAL_MS - (SystemClock.elapsedRealtime() - t0)
            try {
                Thread.sleep(maxOf(rest, 50L))
            } catch (e: InterruptedException) {
                break
            }
        }
        tess.recycle()
    }

    private fun processOnce(tess: TessBaseAPI) {
        ensureCapture()
        if (dropFrame) {
            lastFrame?.recycle()
            lastFrame = null
            dropFrame = false
        }
        val frame = grabFrame() ?: return
        val rect = captureRect ?: return
        val r = Rect(rect)
        if (!r.intersect(0, 0, frame.width, frame.height) || r.width() < 10 || r.height() < 10) return

        val crop = Bitmap.createBitmap(frame, r.left, r.top, r.width(), r.height())
        val prepared = prepare(crop)
        crop.recycle()

        tess.setImage(prepared)
        val text = Text.normalize(tess.getUTF8Text() ?: "")
        prepared.recycle()

        if (text.length >= Config.MIN_CHARS) {
            val stable = lastRead.isNotEmpty() && Text.similarity(text, lastRead) >= Config.SAME_RATIO
            val isNew = lastCopied.isEmpty() || Text.similarity(text, lastCopied) < Config.NEW_RATIO
            if (stable && isNew) {
                lastCopied = text
                deliver(text)
            }
            lastRead = text
        } else {
            // область пустая: забываем, чтобы тот же текст мог появиться снова
            lastRead = ""
            lastCopied = ""
        }
    }

    /** Увеличение и чёрно-белое изображение: так Tesseract читает точнее. */
    private fun prepare(src: Bitmap): Bitmap {
        val k = if (src.width * Config.UPSCALE > 2400) 1 else Config.UPSCALE
        val scaled = if (k == 1) src else Bitmap.createScaledBitmap(src, src.width * k, src.height * k, true)
        val out = Bitmap.createBitmap(scaled.width, scaled.height, Bitmap.Config.ARGB_8888)
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        }
        Canvas(out).drawBitmap(scaled, 0f, 0f, paint)
        if (scaled !== src) scaled.recycle()
        return out
    }

    private fun deliver(text: String) {
        synchronized(history) {
            history.insert(0, "$text\n———\n")
            if (history.length > 20000) history.setLength(20000)
        }
        main.post {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("ocr", text))
            Toast.makeText(this, "Скопировано: $text", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    // ---------------- Завершение ----------------

    override fun onDestroy() {
        alive = false
        watching = false
        running = false
        worker?.interrupt()
        try { wm.removeView(frameView) } catch (_: Exception) {}
        try { wm.removeView(panel) } catch (_: Exception) {}
        virtualDisplay?.release()
        imageReader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
